const find = function(selector) {
	return document.querySelector(selector);
}

const sendMessage = chrome.tabs.sendMessage;
const onMessage = chrome.runtime.onMessage;
const query = chrome.tabs.query;

const container = find('#container');
const showAddBtn = find('#showAddBtn');
const addArea = find('.add-area');
const cancelBtn = find('#cancelBtn');
const confirmBtn = find('#confirmBtn');

const accountBtnArea = find('#accountBtnArea');

const accountNameInput = find('#accountName');
const accountInput = find('#account');
const passwordInput = find('#password');


const Plugin = {

	initButton: function() {
		let that = this;
		let str = '';
		let obj = {};
		let account = '';
		let password = '';
		for (let key in localStorage) {
			if (localStorage.hasOwnProperty(key)) {

				str = that.getStorage(key);

				obj = JSON.parse(str);

				account = obj.account;
				password = obj.password;

				that.createButton(key);
			}
		}
	},


	bindEvent: function() {

		let that = this;

		accountBtnArea.addEventListener('click', function(e){
			e.stopPropagation();
			let target = e.target;
			let className = e.target.className;
			let key = '';
			let storageObj = {};

			if (className === 'account-btn'){

				key = target.parentNode.getAttribute('storage-key');
				storageObj = JSON.parse(that.getStorage(key));
				that.fillTheBlank(storageObj.account, storageObj.password);


			} else if (className === 'fa fa-trash'){
                //delete button
				
				key = target.parentNode.parentNode.getAttribute('storage-key');
				that.removeStorage(key);
				location.reload();


			} else {
				console.log('neither account-btn nor delete-btn.');
			}

		}, false);


		showAddBtn.addEventListener('click', function() {
			addArea.style.display = 'block';
			showAddBtn.style.display = 'none';
		}, false);

		cancelBtn.addEventListener('click', function() {
			location.reload();
		}, false);

		confirmBtn.addEventListener('click', function() {

			//use localstorage to save user credentials. it should be saved as JSON string. don't forget empty check!
            //your implementation

		}, false);

	},

	showPanel: function() {
		addArea.style.display = 'block';
		showAddBtn.style.display = 'none';
	},

	hidePanel: function() {
		addArea.style.display = 'none';
		showAddBtn.style.display = 'block';
	},


	setStorage: function(key, value) {
		localStorage.setItem(key, value);
	},

	getStorage: function(key) {
		let _value = localStorage.getItem(key);
		return _value;
	},

	removeStorage: function(key) {
		localStorage.removeItem(key);
	},

	clearInput: function() {
		//clear all user input
        //your implementation
	},

	createButton: function(wording, account, password) {

		// button-row
		let div = document.createElement('div');
		div.className = 'button-row';
		div.setAttribute('storage-key', wording);

		// account-btn
		let btn = document.createElement('button');
		btn.className = 'account-btn';

		btn.innerText = wording;

		// icon-container
		let iconDiv = document.createElement('div');
		iconDiv.className = 'icon-container';

		// icon
		let icon = document.createElement('i');
		icon.className = 'fa fa-trash';

		iconDiv.appendChild(icon);

		div.appendChild(btn);
		div.appendChild(iconDiv);
		
		accountBtnArea.appendChild(div);
	},

	fillTheBlank: function(account, password){
        //fill the blank on github.com/login
        //check if the tab is active and send message 
        //hint: check /src/content_scripts/github.js for the name of action.
		
	},

	init: function() {
		this.initButton();
		this.bindEvent();
	}

};

Plugin.init();
